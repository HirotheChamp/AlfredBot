import java.util.Date;
public class AlfredQuotes {
    
    public String basicGreeting() {
        // You do not need to code here, this is an example method
        return "Hello, lovely to see you. How are you?";
    }
    
    public String guestGreeting(String name) {
        
        return String.format("Hey %s. It's great to see you.",  name);
    }
    
    public String dateAnnouncement() {
        // YOUR CODE HERE
        return String.format("It is %s.", new Date());
    }
    
    public String respondBeforeAlexis(String conversation) {
       if(conversation.indexOf("Alexis")>-1){
        return "Alexis aint it. How can I help you";
       }
       if(conversation.indexOf("Alfred")>-1){
           return "You know its your best friend here to help! How may I server you?";
       }
        return "Okay... Looks like I'm out of here!";
    }
    
	// NINJA BONUS
	// See the specs to overload the guessGreeting method
    // SENSEI BONUS
    // Write your own AlfredQuote method using any of the String methods you have learned!
}